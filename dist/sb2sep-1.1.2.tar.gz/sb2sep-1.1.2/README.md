# sb2sep
Separate Stellar Component Spectra and Calculate Radial Velocities in SB2 Binary Systems

Please see the [documentation](https://jsinkbaek.github.io/sb2sep/) for a description and guides on how to use the software.
